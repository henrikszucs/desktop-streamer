"use strict";

import path from "node:path";
import process from "node:process";
import fs from "node:fs/promises";
import { exec } from 'node:child_process';

import pngToIco from "png-to-ico";

const main = async function () {
    const mainFolder = path.join("./convert");

    // search png files
    const imgs = [];
    const files = await fs.readdir(mainFolder);
    for (const file of files) {
        if (path.extname(file) === ".png") {
            imgs.push(path.join(mainFolder, file));
        }
    }
    if (imgs.length === 0) {
        throw new Error("No .png files found in the convert folder.");
    }

    // search exe
    let exe = "";
    const list = await fs.readdir(mainFolder);
    for (const file of list) {
        if (path.extname(file) === ".exe") {
            exe = path.join(mainFolder, file);
            break;
        }
    }
    if (exe === "") {
        throw new Error("No .exe file found in the convert folder.");
    }
    
    // convert png files to ico
    const iconFile = path.join(mainFolder, "icon.ico");
    const buff = await pngToIco(imgs);
    await fs.writeFile(iconFile, buff);

    
    // attach icon to exe
    exec("rcedit-x64.exe " + JSON.stringify(exe) + " --set-icon " + JSON.stringify(iconFile),(error, stdout, stderr) => {
        if (error) {
            console.error(`exec error: ${error}`);
            return;
        }
        console.log(`stdout: ${stdout}`);
        console.error(`stderr: ${stderr}`);
    });

};
main();
