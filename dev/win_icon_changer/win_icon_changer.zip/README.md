# Windows app icon changer
Small program to change executable's icon in Windows system.

## Usage
copy .png files and .exe into the 'convert' folder

```
npm install
npm run convert
```

use .exe with new icon (might need file browser refresh to notice the change)